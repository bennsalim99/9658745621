// Lightbox açma ve kapama işlemleri
document.addEventListener('DOMContentLoaded', function() {
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-img');
  const closeBtn = document.querySelector('.close');
  const galleryImages = document.querySelectorAll('.gallery-img');

  // Lightbox'ı açma
  galleryImages.forEach(img => {
    img.addEventListener('click', function() {
      const imgSrc = this.getAttribute('data-src') || this.src;
      lightboxImg.src = imgSrc;
      lightbox.style.display = 'flex'; // Lightbox'ı göster
    });
  });

  // Lightbox'ı kapama
  closeBtn.addEventListener('click', function() {
    lightbox.style.display = 'none';
  });

  // Lightbox dışına tıklanarak kapatma
  lightbox.addEventListener('click', function(event) {
    if (event.target === lightbox) {
      lightbox.style.display = 'none';
    }
  });
});
